<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="GetBigPhoto.php" method="post">
    postsid<input type="text" name="postsid"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
