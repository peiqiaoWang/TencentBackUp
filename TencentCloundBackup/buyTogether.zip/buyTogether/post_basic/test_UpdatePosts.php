<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="UpdatePosts.php" method="post" enctype="multipart/form-data">
    postsid<input type="text" name="postsid"><br />
    headline<input type="text" name="headline"><br />
    文件<label for="file">文件名：</label><br />
    picture<input type="file" name="picture" id="file"><br />
    type<input type="text" name="type"><br />
    commodity<input type="text" name="commodity"><br />
    price<input type="text" name="price"><br />
    unit<input type="text" name="unit"><br />
    member<input type="text" name="peoplenum"><br />
    day<input type="text" name="day"><br />
    hour<input type="text" name="hour"><br />
    description<input type="text" name="description"><br />
    contactinformation<input type="text" name="contactinformation"><br />



    <input type="submit" value="tijiao">

</form>
</body>

</html>
