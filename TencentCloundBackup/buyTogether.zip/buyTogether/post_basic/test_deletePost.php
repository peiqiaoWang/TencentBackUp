<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="DeletePosts.php" method="post">
    messageId<input type="text" name="postsid"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
