<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="IssuePosts.php" method="post" enctype="multipart/form-data">
    <input type="text" name="headline">
    <input type="text" name="issuername">
    <label for="file">文件名：</label>
    <input type="file" name="picture" id="file">
    <input type="text" name="type">
    <input type="text" name="commodity">
    price<input type="text" name="price">
    <input type="text" name="unit">
    member<input type="text" name="peoplenum">
    <input type="text" name="day">
    <input type="text" name="hour">
    <input type="text" name="description">
    <input type="text" name="contactinformation">



    <input type="submit" value="tijiao">

</form>
</body>

</html>
