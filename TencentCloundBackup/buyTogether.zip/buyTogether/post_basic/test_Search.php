<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="Search.php" method="post">
    keyword<input type="text" name="keyword"><br />
    messageId<input type="text" name="postsid"><br />
    messageNum<input type="text" name="postsnum"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
