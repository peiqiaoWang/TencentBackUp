<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="DeleteStatePosts.php" method="post">
    username<input type="text" name="username"><br />
    postsid<input type="text" name="postsid"><br />
    state<input type="text" name="state"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
