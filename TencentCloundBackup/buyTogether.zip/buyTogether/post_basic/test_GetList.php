<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="GetList.php" method="post">
    postsid<input type="text" name="postsid"><br />
    postnum<input type="text" name="postnum"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
