<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="PersonMessage.php" method="post">
    username<input type="text" name="username"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
