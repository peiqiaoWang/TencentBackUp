<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="TypeSearch.php" method="post">
    type<input type="text" name="type"><br />
    postsid<input type="text" name="postsid"><br />
    postsnum<input type="text" name="postsnum"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
