<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="GetUser.php" method="post">
    userName<input type="text" name="userName"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
