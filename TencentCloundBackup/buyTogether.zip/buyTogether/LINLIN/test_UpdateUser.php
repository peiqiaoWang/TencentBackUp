<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="UpdateUser.php" method="post" enctype="multipart/form-data">
    userName<input type="text" name="userName"><br />
    sex<input type="text" name="sex"><br />
    birthday<input type="text" name="birthday"><br />
    school<input type="text" name="school"><br />
    occupation<input type="text" name="occupation"><br />
    <label for="file">headPortait：</label>
    <input type="file" name="headPortait" id="file"><br />
    description<input type="text" name="description"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
