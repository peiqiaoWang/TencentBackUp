<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="Login.php" method="post">
    <input type="text" name="userId">
    <input type="password" name="password">
    <input type="submit" value="tijiao">


</form>
</body>

</html>
