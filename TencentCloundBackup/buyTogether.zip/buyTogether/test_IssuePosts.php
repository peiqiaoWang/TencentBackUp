<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="IssuePosts.php" method="post">
    headline<input type="text" name="headline"><br />
    issuername<input type="text" name="issuername"><br />
    picture<input type="text" name="picture"><br />
    type<input type="text" name="type"><br />
    commodity<input type="text" name="commodity"><br />
    price<input type="text" name="price"><br />
    unit<input type="text" name="unit"><br />
    member<input type="text" name="member"><br />
    deadline<input type="text" name="deadline"><br />
    description<input type="text" name="description"><br />
    contact<input type="text" name="contact"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
