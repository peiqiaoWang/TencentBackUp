<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="ForgetEmailProve.php" method="post">
    <input type="text" name="emailaddress">
    <input type="submit" value="tijiao">

</form>
</body>

</html>
