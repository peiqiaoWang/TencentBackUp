<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="ReportMessage.php" method="post">
    messageId<input type="text" name="messageId"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
