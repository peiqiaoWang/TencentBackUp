<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="AdminLogin.php" method="post">
    adminName<input type="text" name="adminName"><br />
    password<input type="text" name="password"><br />
    <input type="submit" value="commit">


</form>
</body>

</html>
