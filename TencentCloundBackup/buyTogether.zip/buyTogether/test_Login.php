<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="Login.php" method="post">
    userId<input type="text" name="userId"><br />
    password<input type="password" name="password"><br />
    <input type="submit" value="提交">


</form>
</body>

</html>
