<html>
<head>
    <meta charset="utf-8">
</head>
<body>
<form action="ForgetPassword.php" method="post">
    <input type="password" name="newpassword">
    <input type="text" name="emailaddress">
    <input type="text" name="identifyingcode">
    <input type="submit" value="tijiao">
</form>
</body>

</html>
